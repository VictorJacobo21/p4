public class FueraDeRangoException extends Exception {

  public FueraDeRangoException(String message) {
    super(message);
  }
  
}
